package com.mitocode.controller;


import com.mitocode.dto.NombreDTO;
import com.mitocode.dto.PatientDTO;
import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Nombre;
import com.mitocode.model.Patient;
import com.mitocode.service.ICRUD;
import com.mitocode.service.IPatientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/nombres")
public class NombreController {

    @Autowired
    private IPatientService service;

    @Autowired
    private ModelMapper mapper;

    @GetMapping
    public ResponseEntity<List<NombreDTO>> findAll() {
        List<NombreDTO> list = (List<NombreDTO>) service.findAll().stream().map(p -> mapper.map(p, NombreDTO.class)).collect(Collectors.toList());
        return new ResponseEntity<>(list, HttpStatus.OK);
    }


    @GetMapping("/{id}")
    public ResponseEntity<NombreDTO> findById(@PathVariable("id") Integer id) {
       NombreDTO dtoResponse;
        Nombre obj = service.findById(id);
        if (obj == null) {
            throw new ModelNotFoundException("ID NOT FOUND: " + id);
        } else {
            dtoResponse = mapper.map(obj, NombreDTO.class);
        }
        return new ResponseEntity<>(dtoResponse, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Void> save(@Valid @RequestBody NombreDTO dto) {
        Nombre n = service.save(mapper.map(dto, Nombre.class));
        //localhost:8080/patients/3
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(n.getIdNombre()).toUri();
        return ResponseEntity.created(location).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable("id") Integer id) {
        Nombre obj = service.findById(id);
        if (obj == null) {
            throw new ModelNotFoundException("ID NOT FOUND: " + id);
        } else {
            service.delete(id);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


}
