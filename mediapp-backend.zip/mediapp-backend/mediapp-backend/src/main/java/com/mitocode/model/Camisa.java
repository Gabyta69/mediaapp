package com.mitocode.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;

@Entity
//@Table(name = "camisa_table")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Camisa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCamisa;

    @OneToOne
    @JoinColumn(name = "id_Nombre", nullable = false, foreignKey = @ForeignKey(name = "FK_CAMISA_NOMBRE"))
    private Nombre nombre;

    public int idCamisa() {
        return idCamisa;
    }

    public void setIdCamisa(int idCamisa) {
        this.idCamisa = idCamisa;
    }









}
