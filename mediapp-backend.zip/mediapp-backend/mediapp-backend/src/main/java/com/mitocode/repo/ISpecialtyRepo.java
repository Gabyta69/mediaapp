package com.mitocode.repo;

import com.mitocode.model.Specialty;

public interface ISpecialtyRepo extends IGenericRepo<Specialty, Integer> {
}
