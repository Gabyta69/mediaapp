package com.mitocode.repo;

import com.mitocode.model.Nombre;
import com.mitocode.model.Patient;

//@Repository
public interface IPatientRepo extends IGenericRepo<Nombre, Integer> {
}
