package com.mitocode.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
//@Table(name = "nombre_table")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Nombre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idNombre;

    @Column(length = 70, nullable = false)
    private String Nombre;

    @Column(length = 70, nullable = false)
    private String Posicion;

}
