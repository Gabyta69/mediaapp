package com.mitocode.service;

import com.mitocode.model.Specialty;

public interface ISpecialtyService extends ICRUD<Specialty, Integer>{

}
