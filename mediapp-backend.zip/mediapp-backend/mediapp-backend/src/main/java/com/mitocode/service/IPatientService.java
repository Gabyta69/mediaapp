package com.mitocode.service;

import com.mitocode.model.Nombre;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface IPatientService extends ICRUD<Nombre,Integer>{

    Page<Nombre> listPage(Pageable page);

}
